import React from 'react'

function Navbar() {
  return (
    <div className="App ">
   <nav className="navbar navbar-expand-sm nav navbar-dark ">
    <div className='img-logo'>
  <div className="container-fluid  ">
    <div class="collapse navbar-collapse" id="collapsibleNavbar">
      
      
    </div>
  </div>
  </div>
</nav>
  </div>
  )
}

export default Navbar;
